class Chicken implements Animal {
    @Override
    public void makeSound() {
        System.out.println("Cluck!");
    }
}