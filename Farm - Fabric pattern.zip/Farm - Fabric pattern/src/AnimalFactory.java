interface AnimalFactory {
    Animal createAnimal();
}